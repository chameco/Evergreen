#!/usr/bin/python
from src.server import server
server.run()
