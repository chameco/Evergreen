#!/usr/bin/python
from src.client import client
client.run()
